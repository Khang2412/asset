!(function (n) {
  'use strict';

  n.vungle = n.vungle || {};
}(window));
